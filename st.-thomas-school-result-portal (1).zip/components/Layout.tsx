
import React from 'react';
import { LogOut, GraduationCap, MapPin } from 'lucide-react';
import { SCHOOL_NAME, SCHOOL_LOCATION } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
  onLogout: () => void;
  title: string;
  userName?: string;
}

const Layout: React.FC<LayoutProps> = ({ children, onLogout, title, userName }) => {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Top Header */}
      <header className="bg-maroon text-white shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-yellow-400 rounded-full">
                <GraduationCap className="w-8 h-8 text-maroon" />
              </div>
              <div>
                <h1 className="text-xl font-bold tracking-tight uppercase">{SCHOOL_NAME}</h1>
                <div className="flex items-center text-xs opacity-80">
                  <MapPin className="w-3 h-3 mr-1" />
                  {SCHOOL_LOCATION}
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              {userName && (
                <div className="hidden md:block text-right mr-2">
                  <p className="text-xs uppercase opacity-75">Logged in as</p>
                  <p className="font-semibold">{userName}</p>
                </div>
              )}
              <button 
                onClick={onLogout}
                className="flex items-center space-x-2 bg-white/10 hover:bg-white/20 px-4 py-2 rounded-lg transition-all duration-200 border border-white/20"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline font-medium">Logout</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900 border-l-4 border-maroon pl-4">
              {title}
            </h2>
          </div>
          {children}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-100 border-t border-gray-200 py-6 mt-auto">
        <div className="max-w-7xl mx-auto px-4 text-center text-gray-500 text-sm">
          <p>© {new Date().getFullYear()} {SCHOOL_NAME}, Mandsaur. All Rights Reserved.</p>
          <p className="mt-1">Powered by School ERP Portal</p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
