
import { GoogleGenAI } from "@google/genai";
import { Student } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getPerformanceInsights = async (student: Student): Promise<string> => {
  try {
    const totalObtained = student.results.reduce((sum, res) => sum + res.marks, 0);
    const totalMax = student.results.reduce((sum, res) => sum + res.totalMarks, 0);
    const percentage = (totalObtained / totalMax) * 100;

    const subjectsSummary = student.results.map(r => `${r.subject}: ${r.marks}/${r.totalMarks}`).join(', ');

    const prompt = `
      Act as a supportive school principal at St. Thomas School. 
      Review the following student result and provide a short, 2-3 sentence motivational feedback in English and simple Hindi (transliterated).
      
      Student Name: ${student.name}
      Class: ${student.class}
      Marks: ${subjectsSummary}
      Overall Percentage: ${percentage.toFixed(2)}%
      
      Focus on encouraging them to keep improving or celebrating their success.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        maxOutputTokens: 150,
        temperature: 0.7,
      }
    });

    return response.text || "Keep working hard to achieve your dreams!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Great performance! Maintain your focus on all subjects.";
  }
};
