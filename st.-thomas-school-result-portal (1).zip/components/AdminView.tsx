
import React, { useState, useEffect } from 'react';
import { Student, SchoolSettings } from '../types';
import { getStudents, saveStudent, deleteStudent, getSchoolSettings, saveSchoolSettings } from '../services/storageService';
import { Plus, Edit2, Trash2, Search, X, Check, Save, Users, BarChart3, Palette, Download, Upload, FileJson } from 'lucide-react';
import { SUBJECT_LIST } from '../constants';

interface AdminViewProps {
  onSettingsChange?: () => void;
}

const AdminView: React.FC<AdminViewProps> = ({ onSettingsChange }) => {
  const [activeSubTab, setActiveSubTab] = useState<'students' | 'branding' | 'backup'>('students');
  const [students, setStudents] = useState<Student[]>([]);
  const [settings, setSettings] = useState<SchoolSettings>(getSchoolSettings());
  const [searchTerm, setSearchTerm] = useState('');
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    setStudents(getStudents());
  };

  const handleSaveSettings = () => {
    saveSchoolSettings(settings);
    alert('Branding updated successfully!');
    if (onSettingsChange) onSettingsChange();
  };

  const handleEdit = (student: Student) => {
    setEditingStudent(JSON.parse(JSON.stringify(student)));
    setIsModalOpen(true);
  };

  const handleAddNew = () => {
    const newStudent: Student = {
      id: Math.random().toString(36).substr(2, 9),
      rollNo: '',
      name: '',
      class: '10th',
      section: 'A',
      lastUpdated: new Date().toISOString(),
      results: SUBJECT_LIST.map(subject => ({ subject, marks: 0, totalMarks: 100 }))
    };
    setEditingStudent(newStudent);
    setIsModalOpen(true);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Delete this record?')) {
      deleteStudent(id);
      refreshData();
    }
  };

  const handleSaveStudent = () => {
    if (editingStudent && editingStudent.rollNo && editingStudent.name) {
      saveStudent(editingStudent);
      setIsModalOpen(false);
      setEditingStudent(null);
      refreshData();
    }
  };

  // Export Data to JSON File
  const exportData = () => {
    const dataStr = JSON.stringify(students, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = `school_data_backup_${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  // Import Data from JSON File
  const importData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    const file = event.target.files?.[0];
    if (file) {
      fileReader.readAsText(file, "UTF-8");
      fileReader.onload = (e) => {
        try {
          const content = JSON.parse(e.target?.result as string);
          if (Array.isArray(content)) {
            localStorage.setItem('st_thomas_students_db', JSON.stringify(content));
            refreshData();
            alert('Data imported successfully!');
          }
        } catch (err) {
          alert('Invalid file format. Please upload a valid backup JSON.');
        }
      };
    }
  };

  const filteredStudents = students.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    s.rollNo.includes(searchTerm)
  );

  return (
    <div className="space-y-6">
      {/* Sub Navigation */}
      <div className="flex space-x-1 bg-white p-1 rounded-xl shadow-sm border border-gray-100 max-w-md overflow-x-auto">
        <button 
          onClick={() => setActiveSubTab('students')}
          className={`flex-shrink-0 flex items-center justify-center space-x-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeSubTab === 'students' ? 'bg-maroon text-white' : 'text-gray-500 hover:bg-gray-50'}`}
        >
          <Users className="w-4 h-4" />
          <span>Students</span>
        </button>
        <button 
          onClick={() => setActiveSubTab('branding')}
          className={`flex-shrink-0 flex items-center justify-center space-x-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeSubTab === 'branding' ? 'bg-maroon text-white' : 'text-gray-500 hover:bg-gray-50'}`}
        >
          <Palette className="w-4 h-4" />
          <span>Branding</span>
        </button>
        <button 
          onClick={() => setActiveSubTab('backup')}
          className={`flex-shrink-0 flex items-center justify-center space-x-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeSubTab === 'backup' ? 'bg-maroon text-white' : 'text-gray-500 hover:bg-gray-50'}`}
        >
          <FileJson className="w-4 h-4" />
          <span>Backup</span>
        </button>
      </div>

      {activeSubTab === 'students' && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500 font-bold uppercase">Total Students</p>
                <p className="text-2xl font-black text-maroon">{students.length}</p>
              </div>
              <Users className="w-8 h-8 text-gray-200" />
            </div>
            <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500 font-bold uppercase">Last Sync</p>
                <p className="text-lg font-black text-blue-600">Local Cache</p>
              </div>
              <BarChart3 className="w-8 h-8 text-gray-200" />
            </div>
            <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500 font-bold uppercase">Status</p>
                <p className="text-lg font-black text-green-600">Secure</p>
              </div>
              <Check className="w-8 h-8 text-gray-200" />
            </div>
          </div>

          <div className="flex flex-col md:flex-row justify-between items-center gap-4 bg-white p-4 rounded-xl shadow-sm border border-gray-100">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input 
                type="text" 
                placeholder="Search students..."
                className="w-full pl-10 pr-4 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-maroon"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <button onClick={handleAddNew} className="w-full md:w-auto flex items-center justify-center space-x-2 bg-maroon text-white px-6 py-2 rounded-lg font-bold">
              <Plus className="w-4 h-4" />
              <span>Add Student</span>
            </button>
          </div>

          <div className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-gray-50 text-[10px] font-black uppercase text-gray-400 tracking-widest border-b border-gray-100">
                  <tr>
                    <th className="px-6 py-4">Roll No</th>
                    <th className="px-6 py-4">Name</th>
                    <th className="px-6 py-4">Class</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {filteredStudents.map((s) => (
                    <tr key={s.id} className="hover:bg-gray-50/50">
                      <td className="px-6 py-4 font-mono font-bold text-maroon">{s.rollNo}</td>
                      <td className="px-6 py-4 font-semibold">{s.name}</td>
                      <td className="px-6 py-4 text-sm text-gray-500">{s.class}-{s.section}</td>
                      <td className="px-6 py-4 text-right space-x-2">
                        <button onClick={() => handleEdit(s)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-all">
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button onClick={() => handleDelete(s.id)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-all">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {activeSubTab === 'branding' && (
        <div className="bg-white p-8 rounded-2xl shadow-md border border-gray-100 space-y-6">
          <div className="border-b pb-4">
            <h3 className="text-xl font-black text-gray-800">School Branding Settings</h3>
            <p className="text-sm text-gray-500">Customize the look and feel for this school client.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">School Name</label>
                <input 
                  type="text" 
                  className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-maroon"
                  value={settings.name}
                  onChange={(e) => setSettings({...settings, name: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Location Details</label>
                <input 
                  type="text" 
                  className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-maroon"
                  value={settings.location}
                  onChange={(e) => setSettings({...settings, location: e.target.value})}
                />
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Theme Color (Primary)</label>
                <div className="flex items-center space-x-3">
                  <input 
                    type="color" 
                    className="w-12 h-12 border-0 rounded p-0 cursor-pointer"
                    value={settings.primaryColor}
                    onChange={(e) => setSettings({...settings, primaryColor: e.target.value})}
                  />
                  <input 
                    type="text" 
                    className="flex-1 p-2.5 border rounded-lg font-mono uppercase"
                    value={settings.primaryColor}
                    onChange={(e) => setSettings({...settings, primaryColor: e.target.value})}
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="pt-6 border-t flex justify-end">
            <button onClick={handleSaveSettings} className="flex items-center space-x-2 bg-green-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-green-700 shadow-lg transition-all">
              <Save className="w-5 h-5" />
              <span>Apply Changes</span>
            </button>
          </div>
        </div>
      )}

      {activeSubTab === 'backup' && (
        <div className="bg-white p-8 rounded-2xl shadow-md border border-gray-100 space-y-6">
          <div className="border-b pb-4">
            <h3 className="text-xl font-black text-gray-800">Data Backup & Sync</h3>
            <p className="text-sm text-gray-500">Easily update student data across different phones without reinstalling the app.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="p-6 bg-blue-50 rounded-2xl border border-blue-100 space-y-4">
              <div className="w-12 h-12 bg-blue-600 text-white rounded-xl flex items-center justify-center">
                <Download className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-blue-900 text-lg">Export Database</h4>
              <p className="text-sm text-blue-700">Save all student records and marks into a backup file (.json). You can send this file to other teachers.</p>
              <button onClick={exportData} className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition-all flex items-center justify-center space-x-2">
                <Download className="w-4 h-4" />
                <span>Download Backup</span>
              </button>
            </div>

            <div className="p-6 bg-purple-50 rounded-2xl border border-purple-100 space-y-4">
              <div className="w-12 h-12 bg-purple-600 text-white rounded-xl flex items-center justify-center">
                <Upload className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-purple-900 text-lg">Import Database</h4>
              <p className="text-sm text-purple-700">Upload a backup file to restore all student data instantly. This will replace current data.</p>
              <label className="w-full bg-purple-600 text-white py-3 rounded-xl font-bold hover:bg-purple-700 transition-all flex items-center justify-center space-x-2 cursor-pointer">
                <Upload className="w-4 h-4" />
                <span>Upload & Restore</span>
                <input type="file" accept=".json" onChange={importData} className="hidden" />
              </label>
            </div>
          </div>
          
          <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-100">
            <p className="text-xs text-yellow-800 font-medium">
              <strong>Note for Seller:</strong> Use this feature to sync data between your computer and the school's phone. Just export from your PC and import into the school's app.
            </p>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {isModalOpen && editingStudent && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
            <div className="p-6 border-b bg-maroon text-white flex justify-between items-center">
              <h3 className="text-xl font-bold flex items-center space-x-2">
                <Edit2 className="w-5 h-5" />
                <span>Student Marks Entry</span>
              </h3>
              <button onClick={() => setIsModalOpen(false)}><X className="w-6 h-6" /></button>
            </div>
            <div className="p-6 overflow-y-auto space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <input 
                  placeholder="Roll No" className="p-2.5 border rounded-lg"
                  value={editingStudent.rollNo} onChange={(e) => setEditingStudent({...editingStudent, rollNo: e.target.value})}
                />
                <input 
                  placeholder="Student Name" className="p-2.5 border rounded-lg"
                  value={editingStudent.name} onChange={(e) => setEditingStudent({...editingStudent, name: e.target.value})}
                />
              </div>
              <div className="border-t pt-4">
                <h4 className="font-bold text-gray-700 mb-3">Marks (Out of 100)</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {editingStudent.results.map((res, i) => (
                    <div key={i} className="flex justify-between items-center bg-gray-50 p-3 rounded-lg border">
                      <span className="text-sm font-medium">{res.subject}</span>
                      <input 
                        type="number" className="w-16 p-1 border rounded text-center font-bold"
                        value={res.marks} onChange={(e) => {
                          const updated = {...editingStudent};
                          updated.results[i].marks = parseInt(e.target.value) || 0;
                          setEditingStudent(updated);
                        }}
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="p-6 border-t bg-gray-50 flex justify-end">
              <button onClick={handleSaveStudent} className="bg-maroon text-white px-8 py-2 rounded-lg font-bold">Save Student Record</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminView;
