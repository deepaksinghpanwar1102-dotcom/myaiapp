
import { Student, SchoolSettings } from '../types';
import { SCHOOL_NAME, SCHOOL_LOCATION } from '../constants';

const STORAGE_KEY = 'st_thomas_students_db';
const SETTINGS_KEY = 'school_settings_db';

const INITIAL_DATA: Student[] = [
  {
    id: '1',
    rollNo: '1001',
    name: 'Rahul Sharma',
    class: '10th',
    section: 'A',
    lastUpdated: new Date().toISOString(),
    results: [
      { subject: 'Mathematics', marks: 85, totalMarks: 100 },
      { subject: 'Science', marks: 78, totalMarks: 100 },
      { subject: 'English', marks: 92, totalMarks: 100 },
      { subject: 'Hindi', marks: 88, totalMarks: 100 },
      { subject: 'Social Science', marks: 74, totalMarks: 100 },
      { subject: 'Computer Science', marks: 95, totalMarks: 100 },
    ]
  }
];

export const getStudents = (): Student[] => {
  const data = localStorage.getItem(STORAGE_KEY);
  if (!data) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_DATA));
    return INITIAL_DATA;
  }
  return JSON.parse(data);
};

export const saveStudent = (student: Student) => {
  const students = getStudents();
  const index = students.findIndex(s => s.id === student.id);
  if (index >= 0) {
    students[index] = { ...student, lastUpdated: new Date().toISOString() };
  } else {
    students.push({ ...student, lastUpdated: new Date().toISOString() });
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(students));
};

export const deleteStudent = (id: string) => {
  const students = getStudents();
  const filtered = students.filter(s => s.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
};

export const findStudentByRollNo = (rollNo: string): Student | undefined => {
  const students = getStudents();
  return students.find(s => s.rollNo === rollNo);
};

// Settings Storage
export const getSchoolSettings = (): SchoolSettings => {
  const data = localStorage.getItem(SETTINGS_KEY);
  if (!data) {
    const defaultSettings = { 
      name: SCHOOL_NAME, 
      location: SCHOOL_LOCATION, 
      primaryColor: '#8B0000' 
    };
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(defaultSettings));
    return defaultSettings;
  }
  return JSON.parse(data);
};

export const saveSchoolSettings = (settings: SchoolSettings) => {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
};
