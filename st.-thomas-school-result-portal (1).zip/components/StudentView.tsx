
import React, { useEffect, useState } from 'react';
import { Student, Grade } from '../types';
import { Calculator, Award, Star, BookOpen, BrainCircuit, Printer, Share2 } from 'lucide-react';
import { getPerformanceInsights } from '../services/geminiService';

interface StudentViewProps {
  student: Student;
}

const StudentView: React.FC<StudentViewProps> = ({ student }) => {
  const [insight, setInsight] = useState<string>('Analyzing your results...');
  const [loadingInsight, setLoadingInsight] = useState(true);

  const totalObtained = student.results.reduce((sum, res) => sum + res.marks, 0);
  const totalMax = student.results.reduce((sum, res) => sum + res.totalMarks, 0);
  const percentage = (totalObtained / totalMax) * 100;

  useEffect(() => {
    const fetchInsight = async () => {
      setLoadingInsight(true);
      const text = await getPerformanceInsights(student);
      setInsight(text);
      setLoadingInsight(false);
    };
    fetchInsight();
  }, [student]);

  const handlePrint = () => {
    window.print();
  };

  const getGrade = (p: number): Grade => {
    if (p >= 90) return Grade.A_PLUS;
    if (p >= 80) return Grade.A;
    if (p >= 70) return Grade.B;
    if (p >= 60) return Grade.C;
    if (p >= 50) return Grade.D;
    return Grade.F;
  };

  return (
    <div className="space-y-6">
      {/* Top Action Bar */}
      <div className="flex justify-end space-x-3 no-print">
        <button 
          onClick={handlePrint}
          className="flex items-center space-x-2 bg-white border border-gray-200 px-4 py-2 rounded-lg hover:bg-gray-50 font-bold transition-all text-sm shadow-sm"
        >
          <Printer className="w-4 h-4 text-maroon" />
          <span>Download PDF</span>
        </button>
        <button className="flex items-center space-x-2 bg-white border border-gray-200 px-4 py-2 rounded-lg hover:bg-gray-50 font-bold transition-all text-sm shadow-sm">
          <Share2 className="w-4 h-4 text-maroon" />
          <span>Share</span>
        </button>
      </div>

      <div id="printable-area" className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 no-print">
          <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100 flex items-center space-x-4">
            <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600"><Calculator className="w-6 h-6" /></div>
            <div><p className="text-[10px] uppercase font-black text-gray-400">Percentage</p><p className="text-xl font-black text-blue-600">{percentage.toFixed(1)}%</p></div>
          </div>
          <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100 flex items-center space-x-4">
            <div className="w-12 h-12 bg-yellow-50 rounded-xl flex items-center justify-center text-yellow-600"><Award className="w-6 h-6" /></div>
            <div><p className="text-[10px] uppercase font-black text-gray-400">Grade</p><p className="text-xl font-black text-yellow-600">{getGrade(percentage)}</p></div>
          </div>
          <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100 flex items-center space-x-4">
            <div className="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center text-green-600"><Star className="w-6 h-6" /></div>
            <div><p className="text-[10px] uppercase font-black text-gray-400">Result</p><p className="text-xl font-black text-green-600">{percentage >= 33 ? 'Passed' : 'Fail'}</p></div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-md border border-gray-100 overflow-hidden print:border-0 print:shadow-none">
          <div className="px-6 py-4 bg-gray-50 border-b border-gray-100 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <BookOpen className="w-5 h-5 text-maroon" />
              <h3 className="font-black text-gray-800 uppercase tracking-wider">Statement of Marks</h3>
            </div>
            <p className="text-xs text-gray-400 font-bold">Roll No: {student.rollNo}</p>
          </div>
          <div className="overflow-x-auto p-2 sm:p-0">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-gray-100/30 text-[10px] font-black uppercase text-gray-400 tracking-widest">
                  <th className="px-6 py-4">Subject</th>
                  <th className="px-6 py-4">Max</th>
                  <th className="px-6 py-4">Obtained</th>
                  <th className="px-6 py-4">Result</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {student.results.map((res, i) => (
                  <tr key={i} className="hover:bg-gray-50/50">
                    <td className="px-6 py-4 font-bold text-gray-700">{res.subject}</td>
                    <td className="px-6 py-4 text-gray-500 font-medium">{res.totalMarks}</td>
                    <td className="px-6 py-4 font-black text-maroon text-lg">{res.marks}</td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${res.marks >= 33 ? 'bg-green-50 text-green-600 border border-green-100' : 'bg-red-50 text-red-600 border border-red-100'}`}>
                        {res.marks >= 33 ? 'Pass' : 'Fail'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-maroon text-white font-black">
                <tr>
                  <td className="px-6 py-4 uppercase">Total</td>
                  <td className="px-6 py-4">{totalMax}</td>
                  <td className="px-6 py-4 text-2xl">{totalObtained}</td>
                  <td className="px-6 py-4 text-xs font-medium opacity-80">Aggregate Result</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        {/* AI Insight Section */}
        <div className="bg-gradient-to-br from-gray-900 to-gray-800 p-8 rounded-3xl text-white shadow-xl relative overflow-hidden no-print">
          <div className="absolute top-0 right-0 w-32 h-32 bg-maroon/20 rounded-full translate-x-10 -translate-y-10 blur-2xl"></div>
          <div className="relative z-10">
            <div className="flex items-center space-x-3 mb-4">
              <BrainCircuit className="w-8 h-8 text-maroon" />
              <h3 className="text-xl font-black uppercase tracking-tighter">Principal's AI Note</h3>
            </div>
            <div className="text-lg leading-relaxed italic text-gray-300">
              {loadingInsight ? (
                <div className="flex items-center space-x-3">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span className="text-sm">Consulting AI principal...</span>
                </div>
              ) : (
                <p>"{insight}"</p>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Footer for print only */}
      <div className="hidden print:block border-t border-gray-200 mt-12 pt-8 text-center">
        <div className="flex justify-between items-end px-12">
          <div className="text-center">
            <div className="w-32 h-1 bg-gray-200 mb-2"></div>
            <p className="text-xs font-bold uppercase text-gray-500">Class Teacher</p>
          </div>
          <div className="text-center">
            <div className="w-32 h-1 bg-gray-200 mb-2"></div>
            <p className="text-xs font-bold uppercase text-gray-500">Principal Sign</p>
          </div>
        </div>
        <p className="mt-12 text-[10px] text-gray-400">Computer generated report. No signature required for validation.</p>
      </div>

      <style>{`
        @media print {
          .no-print { display: none !important; }
          body { background: white; }
          main { padding: 0 !important; }
          #printable-area { width: 100%; margin: 0; padding: 0; }
        }
      `}</style>
    </div>
  );
};

export default StudentView;
